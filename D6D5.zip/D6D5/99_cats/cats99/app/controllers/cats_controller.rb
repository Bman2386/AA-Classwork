class CatsController < ApplicationController
    def index
        @cats = Cat.all
   
        render :index
    end

    def show
        @cat = Cat.find_by(id: params[:id])
        
        if @cat.nil?
            render plain: "Cat does not exist :("
        else
            render :show
        end
    end

    def new
        @cat = Cat.new
        render :new
    end

    def create
        @cat = Cat.new(cat_params)

        if @cat.save
            render :show
        else
            render :new
        end
    end

    def edit
        @cat = Cat.find_by(id: params[:id])
        render :edit
    end

    def update
        @cat = Cat.find_by(id: params[:id])
        @cat.update(cat_params)
        if @cat.save
            render :show
        else    
            render :edit
        end
    end

    private

    def cat_params
        params
            .require(:cat)
            .permit(:name, :birth_date, :color, :sex, :description)
    end

end